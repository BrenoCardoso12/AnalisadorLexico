# Analisador Léxico (Java 17, Maven) — Breno Cardoso

Este projeto contém um analisador léxico simples, implementado em **Java 17**, pronto para abrir no **NetBeans**.

## Como abrir e executar no NetBeans
1. Abra o NetBeans (ou IntelliJ/Eclipse).
2. **File > Open Project** e selecione a pasta `AnalisadorLexicoJava` (a que contém o `pom.xml`).
3. Clique com o botão direito no projeto e escolha **Run** (ou use `mvn clean package exec:java` no terminal).
4. O `Main` lê o arquivo `src/main/resources/exemplo.txt`, tokeniza e imprime os tokens e a tabela de símbolos.

## Como testar com outro arquivo
- Coloque seu código-fonte em `src/main/resources/seu_arquivo.txt` (UTF-8).
- Ajuste o caminho no `Main` (linha indicada) ou passe o caminho do arquivo como **argumento** de execução.

## Especificação implementada
- Remove comentários (`// ...` e `/* ... */`) e excesso de espaços em branco.
- Reconhece **palavras reservadas**: `inicio`, `fim`, `var`, `leia`, `escreva`, `se`, `senao`.
- Reconhece tokens:
  - `id` (letra + letras/dígitos/_)
  - `nu` (dígitos)
  - `fr` (cadeia entre aspas duplas, aceita caracteres UTF-8)
  - Operadores relacionais (`or`): `<`, `>`, `=`, `!`
  - Operadores matemáticos (`om`): `+`, `*`, `/`, `-`, `%`
  - Operadores lógicos (`ol`): `|`, `&`, `~`
  - Pontuação: `(`, `)`, `:`, `;`
- Constrói **tabela de símbolos** numérica para `id` (primeira ocorrência recebe 1, depois 2, ...).
- Impressão no formato: `[token, lexema]`, com exceções:
  - Identificadores: `[id, N]` (N = número na tabela de símbolos)
  - Números: `[nu, VALOR]`
  - Strings: `[fr, CONTEUDO]` (sem aspas)
- Em caso de lexema inválido, emite **mensagem de erro** com posição (linha/coluna).

## Autor
**Breno Cardoso** — identificado nos cabeçalhos dos arquivos-fonte.
