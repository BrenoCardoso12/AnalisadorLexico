/*

 * Autor do documento: Breno Cardoso

 *
 */
package br.breno.lexico;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * - Remove comentários: // até fim da linha, e /* ... * / (em bloco)
 * 
 */
public class Lexer {
    private final String src;
    private int pos = 0;
    private int line = 1;
    private int col = 1;

    private final SymbolTable symbols;
    private final Map<String, TokenType> reserved = new HashMap<>();

    public Lexer(String source, SymbolTable symbols) {
        this.src = preprocess(source);
        this.symbols = symbols;
        initReserved();
    }

    private void initReserved() {
        reserved.put("inicio", TokenType.INICIO);
        reserved.put("fim", TokenType.FIM);
        reserved.put("var", TokenType.VAR);
        reserved.put("leia", TokenType.LEIA);
        reserved.put("escreva", TokenType.ESCREVA);
        reserved.put("se", TokenType.SE);
        reserved.put("senao", TokenType.SENAO);
    }

    
    private String preprocess(String input) {
        StringBuilder sb = new StringBuilder();
        int i = 0;
        while (i < input.length()) {
            char c = input.charAt(i);
            if (c == '/' && i + 1 < input.length()) {
                char n = input.charAt(i + 1);
                // Comentario de linha
                if (n == '/') {
                    i += 2;
                    while (i < input.length() && input.charAt(i) != '\n') {
                        i++;
                    }
                    
                    sb.append('\n');
                    i++;
                    continue;
                }
                // Comentario de bloco
                if (n == '*') {
                    i += 2;
                    while (i + 1 < input.length() && !(input.charAt(i) == '*' && input.charAt(i + 1) == '/')) {
                        
                        if (input.charAt(i) == '\n') sb.append('\n');
                        i++;
                    }
                    i += 2; 
                    continue;
                }
            }
            sb.append(c);
            i++;
        }
        return sb.toString();
    }

    private boolean isAtEnd() {
        return pos >= src.length();
    }

    private char peek() {
        return isAtEnd() ? '\0' : src.charAt(pos);
    }

    private char advance() {
        char c = peek();
        pos++;
        if (c == '\n') { line++; col = 1; } else { col++; }
        return c;
    }

    private void skipWhitespace() {
        while (!isAtEnd()) {
            char c = peek();
            if (Character.isWhitespace(c)) {
                advance();
            } else {
                break;
            }
        }
    }

    public List<Token> scanTokens() {
        List<Token> tokens = new ArrayList<>();
        while (!isAtEnd()) {
            skipWhitespace();
            if (isAtEnd()) break;
            int startLine = line;
            int startCol = col;
            char c = peek();

            
            if (c == '(') { advance(); tokens.add(new Token(TokenType.LPAREN, "(", startLine, startCol)); continue; }
            if (c == ')') { advance(); tokens.add(new Token(TokenType.RPAREN, ")", startLine, startCol)); continue; }
            if (c == ':') { advance(); tokens.add(new Token(TokenType.COLON, ":", startLine, startCol)); continue; }
            if (c == ';') { advance(); tokens.add(new Token(TokenType.SEMICOLON, ";", startLine, startCol)); continue; }

            
            if ("<>!=+-/*%|&~".indexOf(c) >= 0) {
                advance();
                TokenType ttype;
                if ("<>!=".indexOf(c) >= 0) ttype = TokenType.OR;
                else if ("+-/*%".indexOf(c) >= 0) ttype = TokenType.OM;
                else ttype = TokenType.OL;
                tokens.add(new Token(ttype, String.valueOf(c), startLine, startCol));
                continue;
            }

            
            if (c == '"') {
                advance(); // abre
                StringBuilder sb = new StringBuilder();
                while (!isAtEnd() && peek() != '"') {
                    char ch = advance();
                    if (ch == '\\' && !isAtEnd()) {
                        
                        char nx = advance();
                        if (nx == '"') sb.append('"');
                        else if (nx == '\\') sb.append('\\');
                        else if (nx == 'n') sb.append('\n');
                        else { sb.append(ch).append(nx); }
                    } else {
                        sb.append(ch);
                    }
                }
                if (isAtEnd()) throw error("String não fechada", startLine, startCol);
                advance(); // fecha "
                tokens.add(new Token(TokenType.FR, sb.toString(), startLine, startCol));
                continue;
            }

            
            if (Character.isDigit(c)) {
                StringBuilder sb = new StringBuilder();
                while (!isAtEnd() && Character.isDigit(peek())) {
                    sb.append(advance());
                }
                tokens.add(new Token(TokenType.NU, sb.toString(), startLine, startCol));
                continue;
            }

            
            if (Character.isLetter(c) || c == '_') {
                StringBuilder sb = new StringBuilder();
                while (!isAtEnd() && (Character.isLetterOrDigit(peek()) || peek() == '_')) {
                    sb.append(advance());
                }
                String word = sb.toString();
                TokenType r = reserved.get(word);
                if (r != null) {
                    tokens.add(new Token(r, word, startLine, startCol));
                } else {
                    int idx = symbols.indexOf(word);
                    tokens.add(new Token(TokenType.ID, String.valueOf(idx), startLine, startCol));
                }
                continue;
            }

            //erro léxico
            throw error("Caractere inesperado: '" + c + "'", startLine, startCol);
        }
        tokens.add(new Token(TokenType.EOF, "", line, col));
        return tokens;
    }

    private RuntimeException error(String message, int l, int c) {
        return new RuntimeException(String.format("Erro léxico (%d:%d): %s", l, c, message));
    }
}
