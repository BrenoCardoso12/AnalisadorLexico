/*
 
 * Autor do documento: Breno Cardoso
 
 *
 
 */
package br.breno.lexico;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;

/**
 * Ponto de entrada.
 * Lê um arquivo texto e imprime a sequência de tokens e a tabela de símbolos.
 */
public class Main {

    public static void main(String[] args) throws IOException {
        // === Caminho do arquivo fonte ===
        String file = "src/main/resources/exemplo.txt"; 
        if (args.length > 0) file = args[0];

        String source = Files.readString(Path.of(file), StandardCharsets.UTF_8);

        SymbolTable st = new SymbolTable();
        Lexer lexer = new Lexer(source, st);
        try {
            List<Token> tokens = lexer.scanTokens();
            // Imprime tokens
            for (Token t : tokens) {
                if (t.type == TokenType.EOF) break; //
                System.out.println(t);
            }

            System.out.println();
            System.out.println("Tabela de Símbolos (id -> índice):");
            for (Map.Entry<String, Integer> e : st.snapshot().entrySet()) {
                System.out.printf("%s -> %d%n", e.getKey(), e.getValue());
            }
        } catch (RuntimeException ex) {
            System.err.println(ex.getMessage());
            System.exit(1);
        }
    }
}
